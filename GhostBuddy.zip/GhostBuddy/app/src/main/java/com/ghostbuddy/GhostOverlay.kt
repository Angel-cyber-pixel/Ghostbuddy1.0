package com.ghostbuddy

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/** Ponte tra la schermata di prova e il fantasma che vive sopra le altre app. */
object GhostBus {
    @Volatile
    var overlay: GhostOverlay? = null

    fun react(reaction: GhostReaction) {
        overlay?.react(reaction)
    }
}

/**
 * Il fantasma fluttuante in basso a sinistra. Non intercetta i tocchi:
 * tutto quello che c'è sotto resta cliccabile.
 */
class GhostOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: GhostView? = null

    fun show(): Boolean {
        if (view != null) return true
        if (!Settings.canDrawOverlays(context)) return false

        val d = context.resources.displayMetrics.density
        val params = WindowManager.LayoutParams(
            (WIDTH_DP * d).toInt(),
            (HEIGHT_DP * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = (MARGIN_DP * d).toInt()
            y = (MARGIN_DP * d).toInt()
        }

        return try {
            val ghost = GhostView(context)
            windowManager.addView(ghost, params)
            view = ghost
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide() {
        view?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
    }

    fun react(reaction: GhostReaction) {
        view?.react(reaction)
    }

    companion object {
        const val WIDTH_DP = 130
        const val HEIGHT_DP = 156
        const val MARGIN_DP = 6
    }
}
