package com.ghostbuddy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import com.ghostbuddy.GhostReaction.ALARM
import com.ghostbuddy.GhostReaction.BLUSH
import com.ghostbuddy.GhostReaction.CALL
import com.ghostbuddy.GhostReaction.CURIOUS
import com.ghostbuddy.GhostReaction.EMAIL
import com.ghostbuddy.GhostReaction.IDLE
import com.ghostbuddy.GhostReaction.MESSAGE
import com.ghostbuddy.GhostReaction.MISSED_CALL
import com.ghostbuddy.GhostReaction.MONEY
import com.ghostbuddy.GhostReaction.MUSIC
import com.ghostbuddy.GhostReaction.SOCIAL
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val INK = 0xFF2B2640.toInt()
private val OUTLINE = 0xFFB9B4D6.toInt()
private val HEART_RED = 0xFFFF3B6B.toInt()
private val HEART_PINK = 0xFFFF8FB1.toInt()
private val GOLD = 0xFFFFC93C.toInt()
private val GOLD_DARK = 0xFFE0A100.toInt()
private val PURPLE = 0xFF8E7CFF.toInt()
private val GREEN = 0xFF3DDC84.toInt()

/**
 * Un fantasmino tutto originale, disegnato a mano sul Canvas.
 * Sistema di coordinate interno: 100 x 120 unità, ancorato in basso a sinistra.
 */
class GhostView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var reaction = IDLE
    private var startMs = 0L
    private var u = 1f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()

    fun react(r: GhostReaction) {
        reaction = r
        startMs = SystemClock.uptimeMillis()
        invalidate()
    }

    // ---------- helper di disegno ----------

    private fun fill(color: Int, alpha: Int = 255): Paint {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.alpha = alpha.coerceIn(0, 255)
        return paint
    }

    private fun stroke(color: Int, width: Float, alpha: Int = 255): Paint {
        paint.style = Paint.Style.STROKE
        paint.color = color
        paint.alpha = alpha.coerceIn(0, 255)
        paint.strokeWidth = width * u
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        return paint
    }

    private fun r(left: Float, top: Float, right: Float, bottom: Float): RectF {
        rect.set(left * u, top * u, right * u, bottom * u)
        return rect
    }

    private fun heart(canvas: Canvas, cx: Float, cy: Float, s: Float, color: Int, alpha: Int = 255) {
        path.reset()
        path.moveTo(cx * u, (cy + s * 0.9f) * u)
        path.cubicTo(
            (cx - s * 1.5f) * u, (cy - s * 0.1f) * u,
            (cx - s * 0.8f) * u, (cy - s * 1.1f) * u,
            cx * u, (cy - s * 0.35f) * u
        )
        path.cubicTo(
            (cx + s * 0.8f) * u, (cy - s * 1.1f) * u,
            (cx + s * 1.5f) * u, (cy - s * 0.1f) * u,
            cx * u, (cy + s * 0.9f) * u
        )
        path.close()
        canvas.drawPath(path, fill(color, alpha))
    }

    private fun star(canvas: Canvas, cx: Float, cy: Float, radius: Float, color: Int, rotation: Float) {
        path.reset()
        for (i in 0 until 8) {
            val a = rotation + i * PI.toFloat() / 4f
            val rr = if (i % 2 == 0) radius else radius * 0.42f
            val x = (cx + cos(a) * rr) * u
            val y = (cy + sin(a) * rr) * u
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, fill(color))
    }

    private fun pill(canvas: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, angle: Float) {
        canvas.save()
        canvas.rotate(angle, cx * u, cy * u)
        canvas.drawOval(r(cx - rx, cy - ry, cx + rx, cy + ry), fill(Color.WHITE))
        canvas.drawOval(rect, stroke(OUTLINE, 1.2f))
        canvas.restore()
    }

    private fun fade(p: Float): Int = (255 * min(1f, p * 8f) * (1f - p)).toInt()

    private fun popScale(e: Float): Float = when {
        e < 0.25f -> e / 0.25f * 1.2f
        e < 0.4f -> 1.2f - (e - 0.25f) / 0.15f * 0.2f
        else -> 1f
    }

    /** Particelle che salgono dalla testa (cuori, monete, note). */
    private inline fun rising(
        e: Float, count: Int, speed: Float,
        draw: (x: Float, y: Float, phase: Float, i: Int) -> Unit
    ) {
        for (i in 0 until count) {
            val phase = (e * speed + i.toFloat() / count) % 1f
            val x = 50f + sin(e * 3f + i * 2.1f) * 16f + (i - (count - 1) / 2f) * 8f
            val y = 38f - phase * 34f
            draw(x, y, phase, i)
        }
    }

    // ---------- disegno principale ----------

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        if (reaction != IDLE && reaction.durationMs > 0 && now - startMs > reaction.durationMs) {
            reaction = IDLE
        }
        val g = now / 1000f
        val e = (now - startMs) / 1000f
        u = min(width / 100f, height / 120f)

        canvas.save()
        canvas.translate(0f, height - 120f * u)

        var dx = 0f
        var dy = sin(g * 2.2f) * 2.5f
        var rot = 0f
        when (reaction) {
            CALL -> {
                dx = sin(g * 45f) * 1.6f
                dy = -abs(sin(g * 9f)) * 3f
            }
            MESSAGE, SOCIAL, MONEY -> dy = -abs(sin(e * 7f)) * 6f
            ALARM -> if (e < 0.5f) dy = -sin(e / 0.5f * PI.toFloat()) * 14f else dx = sin(g * 40f) * 1.2f
            MUSIC -> {
                rot = sin(g * 5f) * 8f
                dx = sin(g * 5f) * 3f
            }
            MISSED_CALL -> dy = 3f + sin(g * 1.5f)
            CURIOUS -> if (e < 0.4f) dy = -sin(e / 0.4f * PI.toFloat()) * 10f
            EMAIL -> dy = -abs(sin(e * 5f)) * 3f
            BLUSH -> {
                rot = sin(g * 3f) * 4f
                dx = sin(g * 3f) * 1.5f
            }
            IDLE -> {}
        }

        // ombra a terra
        val lift = (-dy).coerceAtLeast(0f)
        canvas.drawOval(r(34f + lift * 0.3f, 108f, 66f - lift * 0.3f, 113f), fill(Color.BLACK, 40))

        canvas.save()
        canvas.translate(dx * u, dy * u)
        canvas.rotate(rot, 50f * u, 96f * u)
        drawArms(canvas, g)
        drawBody(canvas, g)
        drawFace(canvas, g)
        drawEffects(canvas, g, e)
        canvas.restore()

        canvas.restore()
        postInvalidateDelayed(33)
    }

    private fun drawArms(canvas: Canvas, g: Float) {
        val left: Float
        val right: Float
        when (reaction) {
            BLUSH -> return
            MESSAGE, SOCIAL, MONEY, MUSIC -> {
                left = 40f + sin(g * 10f) * 15f
                right = -40f - sin(g * 10f + 1f) * 15f
            }
            CALL, ALARM -> {
                left = 50f + sin(g * 30f) * 12f
                right = -50f - sin(g * 30f + 1f) * 12f
            }
            MISSED_CALL -> {
                left = -15f
                right = 15f
            }
            else -> {
                left = -30f + sin(g * 2.2f) * 5f
                right = 30f - sin(g * 2.2f) * 5f
            }
        }
        pill(canvas, 22f, 76f, 5.5f, 3.3f, left)
        pill(canvas, 78f, 76f, 5.5f, 3.3f, right)
    }

    private fun drawBody(canvas: Canvas, g: Float) {
        path.reset()
        path.moveTo(24f * u, 60f * u)
        path.arcTo(r(24f, 34f, 76f, 86f), 180f, 180f)
        path.lineTo(76f * u, 96f * u)
        val w = 52f / 3f
        for (i in 0 until 3) {
            val x0 = 76f - i * w
            val x1 = x0 - w
            val amp = 14f + sin(g * 4f + i * 1.7f) * 3f
            path.quadTo((x0 + x1) / 2f * u, (96f + amp) * u, x1 * u, 96f * u)
        }
        path.close()
        canvas.drawPath(path, fill(Color.WHITE))
        canvas.drawPath(path, stroke(OUTLINE, 1.3f))
    }

    private fun drawFace(canvas: Canvas, g: Float) {
        val blush = reaction == BLUSH
        val cheekColor = if (blush) 0xFFFF4D6D.toInt() else 0xFFFFA3B8.toInt()
        val cheekAlpha = if (blush) 215 + (sin(g * 6f) * 30f).toInt() else 100
        val cheekR = if (blush) 5.6f else 4.2f
        canvas.drawCircle(37f * u, 70f * u, cheekR * u, fill(cheekColor, cheekAlpha))
        canvas.drawCircle(63f * u, 70f * u, cheekR * u, fill(cheekColor, cheekAlpha))

        drawEye(canvas, 42f, 62f, 0, g)
        drawEye(canvas, 58f, 62f, 1, g)
        drawMouth(canvas)

        if (blush) {
            // si copre il viso con le manine
            pill(canvas, 38f, 74f, 6f, 3.8f, -25f)
            pill(canvas, 62f, 74f, 6f, 3.8f, 25f)
        }
    }

    private fun drawEye(canvas: Canvas, x: Float, y: Float, side: Int, g: Float) {
        when (reaction) {
            BLUSH, MESSAGE, MUSIC ->
                canvas.drawArc(r(x - 3.6f, y - 2.6f, x + 3.6f, y + 4.6f), 200f, 140f, false, stroke(INK, 1.8f))
            SOCIAL -> heart(canvas, x, y, 3.6f + sin(g * 10f) * 0.6f, HEART_RED)
            MONEY -> star(canvas, x, y, 4.8f + sin(g * 8f) * 0.5f, GOLD, g * 1.5f)
            CALL, ALARM -> {
                canvas.drawOval(r(x - 4.4f, y - 5.4f, x + 4.4f, y + 5.4f), fill(INK))
                canvas.drawCircle((x + 1.3f) * u, (y - 2f) * u, 1.5f * u, fill(Color.WHITE))
            }
            MISSED_CALL -> {
                canvas.drawOval(r(x - 2.8f, y - 2.6f, x + 2.8f, y + 4.6f), fill(INK))
                canvas.drawCircle((x + 0.8f) * u, (y - 0.5f) * u, 1f * u, fill(Color.WHITE))
                if (side == 0) {
                    canvas.drawLine((x - 4f) * u, (y - 6f) * u, (x + 3f) * u, (y - 9f) * u, stroke(INK, 1.5f))
                } else {
                    canvas.drawLine((x - 3f) * u, (y - 9f) * u, (x + 4f) * u, (y - 6f) * u, stroke(INK, 1.5f))
                }
            }
            else -> {
                val blink = (g * 1000f).toLong() % 3400L < 140L
                val sy = if (blink) 0.15f else 1f
                val look = when (reaction) {
                    EMAIL -> 1.6f
                    CURIOUS -> sin(g * 3f) * 1.6f
                    else -> 0f
                }
                canvas.drawOval(r(x + look - 3f, y - 4f * sy, x + look + 3f, y + 4f * sy), fill(INK))
                if (!blink) canvas.drawCircle((x + look + 1f) * u, (y - 1.6f) * u, 1.1f * u, fill(Color.WHITE))
            }
        }
    }

    private fun drawMouth(canvas: Canvas) {
        when (reaction) {
            CALL, ALARM -> canvas.drawOval(r(48.2f, 69f, 51.8f, 74.5f), fill(INK))
            CURIOUS -> canvas.drawOval(r(48.8f, 69.5f, 51.2f, 72.5f), fill(INK))
            MISSED_CALL -> canvas.drawArc(r(46.5f, 72f, 53.5f, 77.5f), 200f, 140f, false, stroke(INK, 1.6f))
            MESSAGE, SOCIAL, MONEY, MUSIC -> canvas.drawArc(r(46f, 67f, 54f, 75.5f), 0f, 180f, true, fill(INK))
            BLUSH -> canvas.drawArc(r(48f, 69.5f, 52f, 72.5f), 20f, 140f, false, stroke(INK, 1.4f))
            else -> canvas.drawArc(r(46.5f, 68f, 53.5f, 73.5f), 20f, 140f, false, stroke(INK, 1.6f))
        }
    }

    private fun drawEffects(canvas: Canvas, g: Float, e: Float) {
        when (reaction) {
            BLUSH -> rising(e, 5, 0.5f) { x, y, p, _ ->
                heart(canvas, x, y, 2.6f + p, 0xFFFF5C8A.toInt(), fade(p))
            }

            SOCIAL -> rising(e, 5, 0.6f) { x, y, p, i ->
                heart(canvas, x, y, 3.2f, if (i % 2 == 0) HEART_RED else HEART_PINK, fade(p))
            }

            CALL -> {
                val px = 80f
                val py = 46f
                canvas.save()
                canvas.rotate(sin(g * 45f) * 10f, px * u, py * u)
                canvas.drawRoundRect(r(px - 5f, py - 8f, px + 5f, py + 8f), 2f * u, 2f * u, fill(INK))
                canvas.drawRoundRect(r(px - 3.8f, py - 6.2f, px + 3.8f, py + 5.2f), 1f * u, 1f * u, fill(GREEN))
                canvas.restore()
                for (k in 0..2) {
                    val p = (e * 2.5f + k / 3f) % 1f
                    val rho = 9f + k * 5f
                    canvas.drawArc(
                        r(px - rho, py - rho, px + rho, py + rho), -35f, 70f, false,
                        stroke(GREEN, 1.4f, (255 * (1f - p)).toInt())
                    )
                }
            }

            MISSED_CALL -> {
                for (i in 0..1) {
                    val p = (e * 1.2f + i * 0.5f) % 1f
                    val ex = if (i == 0) 41f else 59f
                    canvas.drawCircle(ex * u, (66f + p * 14f) * u, 1.6f * u, fill(0xFF6FC3FF.toInt(), (255 * (1f - p)).toInt()))
                }
                canvas.drawRoundRect(r(77f, 38f, 87f, 54f), 2f * u, 2f * u, fill(0xFF8A86A3.toInt()))
                canvas.drawLine(79f * u, 43f * u, 85f * u, 49f * u, stroke(0xFFFF4D4D.toInt(), 1.6f))
                canvas.drawLine(85f * u, 43f * u, 79f * u, 49f * u, stroke(0xFFFF4D4D.toInt(), 1.6f))
            }

            MESSAGE -> {
                val s = popScale(e)
                canvas.save()
                canvas.scale(s, s, 62f * u, 34f * u)
                canvas.drawRoundRect(r(62f, 10f, 96f, 30f), 9f * u, 9f * u, fill(PURPLE))
                path.reset()
                path.moveTo(68f * u, 29f * u)
                path.lineTo(65f * u, 37f * u)
                path.lineTo(77f * u, 29f * u)
                path.close()
                canvas.drawPath(path, fill(PURPLE))
                for (i in 0..2) {
                    canvas.drawCircle((71f + i * 8f) * u, (20f + sin(g * 8f + i * 0.9f) * 2f) * u, 2f * u, fill(Color.WHITE))
                }
                canvas.restore()
            }

            EMAIL -> {
                val by = sin(g * 5f) * 1.5f
                canvas.save()
                canvas.translate(0f, by * u)
                canvas.drawRoundRect(r(66f, 18f, 92f, 34f), 2f * u, 2f * u, fill(Color.WHITE))
                canvas.drawRoundRect(rect, 2f * u, 2f * u, stroke(OUTLINE, 1.3f))
                path.reset()
                path.moveTo(66f * u, 19f * u)
                path.lineTo(79f * u, 28f * u)
                path.lineTo(92f * u, 19f * u)
                canvas.drawPath(path, stroke(OUTLINE, 1.3f))
                canvas.drawCircle(92f * u, 18f * u, 3.2f * u, fill(0xFFFF4D4D.toInt()))
                canvas.restore()
            }

            ALARM -> {
                canvas.save()
                canvas.rotate(sin(g * 40f) * 16f, 78f * u, 22f * u)
                canvas.drawArc(r(70f, 22f, 86f, 42f), 180f, 180f, true, fill(GOLD))
                canvas.drawRoundRect(r(68f, 31f, 88f, 34.5f), 1.7f * u, 1.7f * u, fill(GOLD_DARK))
                canvas.drawCircle(78f * u, 37f * u, 2.2f * u, fill(GOLD_DARK))
                canvas.drawCircle(78f * u, 21.5f * u, 1.6f * u, fill(GOLD_DARK))
                canvas.restore()
                val a = (160 + sin(g * 30f) * 90f).toInt()
                for (sign in intArrayOf(-1, 1)) {
                    canvas.drawLine((78f + sign * 13f) * u, 28f * u, (78f + sign * 16.5f) * u, 24f * u, stroke(GOLD, 1.3f, a))
                }
            }

            MONEY -> rising(e, 4, 0.7f) { x, y, p, _ ->
                val a = fade(p)
                canvas.drawCircle(x * u, y * u, 3.4f * u, fill(GOLD, a))
                canvas.drawCircle(x * u, y * u, 3.4f * u, stroke(GOLD_DARK, 0.9f, a))
                textPaint.textSize = 4.2f * u
                textPaint.color = 0xFFB07A00.toInt()
                textPaint.alpha = a.coerceIn(0, 255)
                canvas.drawText("€", x * u, (y + 1.5f) * u, textPaint)
            }

            MUSIC -> rising(e, 3, 0.45f) { x, y, p, _ ->
                val a = fade(p)
                canvas.save()
                canvas.rotate(-20f, x * u, y * u)
                canvas.drawOval(r(x - 2.4f, y - 1.7f, x + 2.4f, y + 1.7f), fill(PURPLE, a))
                canvas.restore()
                canvas.drawLine((x + 2f) * u, (y - 0.6f) * u, (x + 2f) * u, (y - 9f) * u, stroke(PURPLE, 1.2f, a))
                canvas.drawLine((x + 2f) * u, (y - 9f) * u, (x + 5.5f) * u, (y - 6.5f) * u, stroke(PURPLE, 1.2f, a))
            }

            CURIOUS -> {
                val s = popScale(e)
                canvas.save()
                canvas.scale(s, s, 50f * u, 22f * u)
                canvas.rotate(sin(g * 14f) * 6f, 50f * u, 22f * u)
                canvas.drawRoundRect(r(48.3f, 4f, 51.7f, 17f), 1.7f * u, 1.7f * u, fill(0xFFFF6B6B.toInt()))
                canvas.drawCircle(50f * u, 21f * u, 2f * u, fill(0xFFFF6B6B.toInt()))
                canvas.restore()
            }

            else -> {}
        }
    }
}
